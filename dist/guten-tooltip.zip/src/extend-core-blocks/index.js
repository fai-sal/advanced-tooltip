/**
 * Internal dependencies
 */
import './image';
