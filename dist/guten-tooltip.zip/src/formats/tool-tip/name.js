/**
 * Tooltip Name
 */
const NAME = 'guten/tool-tip';

export default NAME;
