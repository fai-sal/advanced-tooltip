/**
 * Internal dependencies
 */
import Tooltip from './tooltip';
new Tooltip();
