/**
 * Internal dependencies
 */
import './formats';
import './extend-core-blocks';
